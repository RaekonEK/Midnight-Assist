package com.one_studio;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MidnightAssisitModMenu implements ModMenuApi {
@Override
public ConfigScreenFactory<?> getModConfigScreenFactory() {
return parent -> {
ConfigBuilder builder = ConfigBuilder.create()
.setParentScreen(parent)
.setTitle(class_2561.method_43471("title.midnight-assist.config"))
.setSavingRunnable(MidnightAssisitConfig.INSTANCE::save);

var entryBuilder = builder.entryBuilder();
var general = builder.getOrCreateCategory(class_2561.method_43471("category.midnight-assist.general"));

general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("option.midnight-assist.global_enabled"), MidnightAssisitConfig.INSTANCE.getData().getGlobalEnabled())
.setDefaultValue(true)
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setGlobalEnabled)
.build());

general.addEntry(entryBuilder.startDoubleField(class_2561.method_43471("option.midnight-assist.aim_accuracy"), MidnightAssisitConfig.INSTANCE.getData().getAimAccuracy())
.setDefaultValue(0.2)
.setMin(0.0)
.setMax(1.0)
.setTooltip(class_2561.method_43471("option.midnight-assist.aim_accuracy.tooltip"))
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setAimAccuracy)
.build());

general.addEntry(entryBuilder.startDoubleField(class_2561.method_43471("option.midnight-assist.aim_speed"), MidnightAssisitConfig.INSTANCE.getData().getAimSpeed())
.setDefaultValue(0.5)
.setMin(0.0)
.setMax(1.0)
.setTooltip(class_2561.method_43471("option.midnight-assist.aim_speed.tooltip"))
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setAimSpeed)
.build());

general.addEntry(entryBuilder.startEnumSelector(
class_2561.method_43471("option.midnight-assist.target_priority"),
MidnightAssisitConfig.TargetPriority.class,
MidnightAssisitConfig.INSTANCE.getData().getTargetPriority()
).setDefaultValue(MidnightAssisitConfig.TargetPriority.NEAREST)
.setTooltip(class_2561.method_43471("option.midnight-assist.target_priority.tooltip"))
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setTargetPriority)
.build());

general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43471("option.midnight-assist.melee_lock_on"), MidnightAssisitConfig.INSTANCE.getData().getMeleeLockOnEnabled())
.setDefaultValue(true)
.setTooltip(class_2561.method_43471("option.midnight-assist.melee_lock_on.tooltip"))
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setMeleeLockOnEnabled)
.build());

general.addEntry(entryBuilder.startEnumSelector(class_2561.method_43471("option.midnight-assist.preset"), MidnightAssisitConfig.Preset.class, MidnightAssisitConfig.Preset.NONE)
.setSaveConsumer(MidnightAssisitConfig.INSTANCE.getData()::setLastAppliedPreset)
.setDefaultValue(MidnightAssisitConfig.Preset.NONE)
.setTooltip(class_2561.method_43471("option.midnight-assist.preset.tooltip"))
.build());

var entities = builder.getOrCreateCategory(class_2561.method_43471("category.midnight-assist.entities"));

List<String> sortedEntities = new ArrayList<>(MidnightAssisitConfig.INSTANCE.getData().getEnabledEntities().keySet());
Collections.sort(sortedEntities);

for (String id : sortedEntities) {
var entityType = MidnightAssisitConfig.INSTANCE.getEntityType(id);

if (entityType == null) continue;

var entityName = entityType.getName();
boolean smartDefault = MidnightAssisitConfig.INSTANCE.isSmartDefault(entityType, id);

entities.addEntry(entryBuilder.startBooleanToggle(entityName, MidnightAssisitConfig.INSTANCE.getData().getEnabledEntities().getOrDefault(id, smartDefault))
.setDefaultValue(smartDefault)
.setSaveConsumer(value -> MidnightAssisitConfig.INSTANCE.getData().getEnabledEntities().put(id, value))
.build());
}

return builder.build();
};
}
}


