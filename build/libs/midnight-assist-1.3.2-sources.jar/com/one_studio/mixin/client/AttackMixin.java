package com.one_studio.mixin.client;

import com.one_studio.MidnightAssisitClient;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class AttackMixin {
@Inject(at = @At("HEAD"), method = "doAttack", cancellable = true)
private void onDoAttack(CallbackInfoReturnable<Boolean> cir) {
if (MidnightAssisitClient.tryInterceptAttack((class_310)(Object)this)) {
cir.setReturnValue(false);
}
}
}

