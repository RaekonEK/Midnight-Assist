package com.one_studio
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.minecraft.server.command.CommandManager
import net.minecraft.text.Text
import org.slf4j.LoggerFactory
object MidnightAssisit : ModInitializer { private val logger = LoggerFactory.getLogger("midnight-assist")
override fun onInitialize() {
logger.info("Hello Fabric world!")
MidnightAssisitConfig.load()
CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
dispatcher.register(
CommandManager.literal("midnight")
.then(CommandManager.literal("reload")
.executes { context ->
MidnightAssisitConfig.load()
val prefix = Text.translatable("chat.midnight-assist.prefix")
val message = Text.translatable("chat.midnight-assist.reloaded")
context.source.sendFeedback({ prefix.copy().append(message) }, false)
1
}
)
.then(CommandManager.literal("toggle")
.executes { context ->
MidnightAssisitConfig.data.globalEnabled = !MidnightAssisitConfig.data.globalEnabled
MidnightAssisitConfig.save()
val statusKey = if (MidnightAssisitConfig.data.globalEnabled) "chat.midnight-assist.enabled" else "chat.midnight-assist.disabled"
val prefix = Text.translatable("chat.midnight-assist.prefix")
val status = Text.translatable(statusKey)
context.source.sendFeedback({ prefix.copy().append(status) }, false)
1
}
)
.executes { context ->
val prefix = Text.translatable("chat.midnight-assist.prefix")
val usage = Text.translatable("chat.midnight-assist.usage")
context.source.sendFeedback({ prefix.copy().append(usage) }, false)
1
}
)
}
}
}
