package com.one_studio.mixin.client;

import com.one_studio.MidnightAssisitClient;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class CameraMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        float partialTicks = tickCounter.method_60637(tick);
        MidnightAssisitClient.applyPartialTicks(partialTicks);
    }
}
